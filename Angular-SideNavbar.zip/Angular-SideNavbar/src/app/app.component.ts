import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

declare let $: any ;


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit  {
  user :Users
  myForm!:NgForm
  @ViewChild('selectElem') el!:ElementRef;

  constructor()
  {
    this.user=new Users()
  }
  ngOnInit()
  {
 

  
  }

  onSubmit(form:NgForm)
  {
    
    console.log(this.user)
        //  console.log(form)   
        //  console.log(form.value)

  }




ToogleNavBar()
{
    $("#header").toggleClass("body-pd");
    $("#nav-bar").toggleClass("show");
    $("#body").toggleClass("body-pd");
    $(".nav_link").removeClass("active");
    $("#header-toggle").toggleClass("bx-x");
    $("#header").toggleClass("header-pd");
      
}

}

export class Users{
  email!:string
  password!:string
}
  